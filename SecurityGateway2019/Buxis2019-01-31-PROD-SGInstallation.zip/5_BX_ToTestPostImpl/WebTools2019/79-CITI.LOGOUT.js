<SCRIPT EDATE="04/04/2015" ID="CITI.LOGOUT" NAME="LogOut Citi" GROUP="CITI.SEGURIDAD" UED="20150404" ORD="">
	<DESCRIPTION></DESCRIPTION>
	<PARAMETERS>
		<PARAMETER parOrder="1" id="token" parType="1" parTypeName="String"/>
	</PARAMETERS>
	<REFERENCES>
		<REFERENCE ID="CITI.COMUN"/>
		<REFERENCE ID="TYPELIB"/>
	</REFERENCES>
	<CODE LANG="JavaScript">
		//2019-Ene-18
			empowerTypes();

			var tkn = service.getParameter('token');  

			var srv = engine.createService("CITI.LOGOUT.UPD","DATA");
			//srv.setParameter('token', tkn);
			srv.setParameter('s_id', tkn);
			srv.run();

			var ses = GetSessionData(tkn);
			var sg = new ActiveXObject('BxSecurityGateway2018v2.ClassLibrary.SGLogin') ;

			sql = "SELECT CODIGO, DESCRI_COD FROM QSCODIGOS WHERE GRUPO = 30018";
			var rssg=engine.con.execute (sql);
			while (!rssg.eof){
			  
				switch (String(rssg.fields('CODIGO').value).rtrim()){
					case 'URL':
						 sg.SecurityGateWayServer = String(rssg.fields('DESCRI_COD').value).rtrim();
						 break;
					case 'APPID':
						 sg.ApplicationID = String(rssg.fields('DESCRI_COD').value).rtrim();
						 break;
				}
				rssg.movenext;
			}
			rssg.close;

			sg.Logout(String(ses.USR).rtrim());
	</CODE>
	<ACCESSRULES><ACCESSRULE ID="admin"/><ACCESSRULE ID="user"/></ACCESSRULES>
</SCRIPT>