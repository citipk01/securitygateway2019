<SCRIPT EDATE="01/02/2016" ID="CITI.LOGIN" NAME="Citi Login" GROUP="CITI.SEGURIDAD" UED="19000101" ORD="">
	<DESCRIPTION>Login al Portal Buxis Citi a trav�s del Security Gateway de Citibank.</DESCRIPTION>
	<PARAMETERS>
		<PARAMETER parOrder="1" id="username" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="2" id="password" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="3" id="netuser" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="4" id="iphost" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="5" id="namehost" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="6" id="ip" parType="1" parTypeName="String"/>
	</PARAMETERS>
	<REFERENCES>
		<REFERENCE ID="TYPELIB"/>
		<REFERENCE ID="JSON"/>
	</REFERENCES>
	<CODE LANG="JavaScript">
		// / / /  / ***************	2019 01 31 *******************//////////////////////////

		empowerTypes();
		var usr = service.getParameter('username').toUpperCase();
		var pwd = service.getParameter('password');
		//var iphost = service.getParameter('iphost');
		var iphost = service.getParameter('ip');      
		//var namehost = service.getParameter('namehost');   
		var namehost = iphost;
		var netuser = service.getParameter('netuser');   
		//var iphost = ' ';
		//var namehost = ' ';
		//var netuser = ' ';
		var sg = new ActiveXObject('BxSecurityGateway2018v2.ClassLibrary.SGLogin') ;
		var nombre = '';  
		var token = '';  
		var funcs = [];
		var funcsJson = '';
		var msj = '';
		var sql = '';
		var logOk = false;
		var time = 'N';
		
		//sg.SecurityGateWayServer = 'https://sgsit.nam.nsroot.net:7209/SGAdmin/LegacyController';
		//sg.ApplicationID = '20322020';
		
		
		sql = "SELECT CODIGO, DESCRI_COD FROM QSCODIGOS WHERE GRUPO = 30018";
		var rssg=engine.con.execute (sql);
		while (!rssg.eof){
		  
			switch (String(rssg.fields('CODIGO').value).rtrim()){
				case 'URL':
					 sg.SecurityGateWayServer = String(rssg.fields('DESCRI_COD').value).rtrim();
					 break;
				case 'APPID':
				     sg.ApplicationID = String(rssg.fields('DESCRI_COD').value).rtrim();
					 break;
			}
			rssg.movenext;
		}
		rssg.close;
		
		
		try
		{     
			sg.setConfigXmlFilePath('C:\\Windows\\SysWOW64\\config.xml');
			// sg.setApplicationName("SGDemoNET");	
			sg.Login(usr, pwd);
			nombre = sg.Name;
			funcsStr = sg.GetFunctionsStr(usr, pwd);
			funcs = funcsStr.split(",");	
			if (funcs.length == 0){
				funcsStr = "HOME,MIFORMVAC";
			}else{
				var encontroHome = false;
				var encontroMiFormVac = false;
				for(f=0;f&lt;funcs.length;f++)
				{
					if (funcs[f] == "HOME"){
						encontroHome = true;				
					}                    
					if (funcs[f] == "MIFORMVAC"){
						encontroMiFormVac = true;
					}
				}
				if (!encontroHome){
					funcsStr += ",HOME";
				}
				if (!encontroMiFormVac){
					funcsStr += ",MIFORMVAC";
				}		
			}
			funcs = funcsStr.split(",");
			logOk = true;
		}
		catch (err)
		{
			if (sg.HasToChangePassword)
			{
				token = TraeGUID();
				result.setvalue('token', 'STRING', token);
				result.setvalue('status','INTEGER',1);
			}else{
				if (sg.ReturnCode != 0x14b){
					result.setError(err.message); 
				}else{
					nombre = sg.Name;
					funcsStr = "HOME,MIFORMVAC";
					funcs = funcsStr.split(",");
					time = 'Y';	
					logOk = true;
				}
			}  
			result.setError(err.message); 
		} 
		
		  
		if (logOk){
		  
			// Usuario correcto -&gt; Crear Sesion
			token = TraeGUID(); 
			//result.setError(iphost);
			CreateSession(token, usr, iphost,namehost, netuser, funcs, time);  
			
			result.setvalue('token', 'STRING', token);
			result.setvalue('nombre', 'STRING', nombre);
			var funcsStr = '';                            
			
			for(i=0;i&lt;funcs.length -1;i++){
				if (i==0){
					funcsStr = funcs[i];
				}else{
					funcsStr += ','+ funcs[i];
				}
			}	
			result.setvalue('permisos', 'STRING', funcsStr);
			result.setvalue('status','INTEGER',0);      
		    	
			 
		
		}  
		
		function TraeGUID(){
		
			var srv = engine.createService("CITI.GET.GUID","DATA");
			srv.run();   	
			return srv.getField(0, 'GUID');
		
		}
		
		function CreateSession(token, usr, ip,name, netuser,  funcs, timeout){
		
			//var s_id = TraeGUID();
			var s_id = token;
			
			var srv = engine.createService("CITI.SESSION.INS","DATA");
			srv.setParameter('S_ID', s_id);
			//srv.setParameter('TOKEN', token);
			srv.setParameter('USR', usr);
			srv.setParameter('IPHOST', ip);
			srv.setParameter('NAMEHOST', name);
			srv.setParameter('NETUSER', netuser);
			srv.setParameter('TIMEOUT', timeout);
			srv.run();	
			
			for(i=0;i&lt;funcs.length -1;i++){
				sql = "INSERT INTO CB_SID_PRF(S_ID, PRF)";
				sql += " VALUES ('" + s_id + "','" + funcs[i] + "')";
				engine.con.execute (sql);
			}
		}
	</CODE>
	<ACCESSRULES><ACCESSRULE ID="admin"/></ACCESSRULES>
</SCRIPT>
