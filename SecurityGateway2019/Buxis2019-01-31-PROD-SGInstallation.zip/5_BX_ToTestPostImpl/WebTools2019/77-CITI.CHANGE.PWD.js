<SCRIPT EDATE="01/01/1900" ID="CITI.CHANGE.PWD" NAME="Citi Change Password" GROUP="CITI.SEGURIDAD" UED="19000101" ORD="">
	<DESCRIPTION></DESCRIPTION>
	<PARAMETERS>
		<PARAMETER parOrder="1" id="username" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="2" id="oldpass" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="3" id="newpass" parType="1" parTypeName="String"/>
		<PARAMETER parOrder="4" id="newpass2" parType="1" parTypeName="String"/>
	</PARAMETERS>
	<REFERENCES>
		<REFERENCE ID="TYPELIB"/>
	</REFERENCES>
	<CODE LANG="JavaScript">     
	//2019-Ene-17
		empowerTypes();
		var usr = service.getParameter('username');
		var oldpass = service.getParameter('oldpass');
		var newpass = service.getParameter('newpass');   
		var newpass2 = service.getParameter('newpass2');   
		
		var sg = new ActiveXObject('BxSecurityGateway2018v2.ClassLibrary.SGLogin') ;
		
		/*sg.SecurityGateWayServer = 'https://sgsit.nam.nsroot.net:7209/SGAdmin/SGController';
		sg.ApplicationID = 12345;*/
		
		sql = "SELECT CODIGO, DESCRI_COD FROM QSCODIGOS WHERE GRUPO = 30018";
		var rssg=engine.con.execute (sql);
		while (!rssg.eof){
		  
			switch (String(rssg.fields('CODIGO').value).rtrim()){
				case 'URL':
					 sg.SecurityGateWayServer = String(rssg.fields('DESCRI_COD').value).rtrim();
					 break;
				case 'APPID':
				     sg.ApplicationID = String(rssg.fields('DESCRI_COD').value).rtrim();
					 break;
			}
			rssg.movenext;
		}
		rssg.close;
		
		try{
			sg.ChangePassword(usr, oldpass, newpass, newpass2);
			result.setvalue('status','INTEGER',0);
		}catch(err){
			if (sg.ReturnCode != 20000){
				result.setvalue('status','INTEGER',1);
				result.seterror(err.message);
			}else{
				// Change Password on Buxis
				if (newpass != newpass2){
					result.setvalue('status','INTEGER',1);
					result.seterror('Claves distintas.');			
				}else{
					var srv = engine.createService("CITI.USER.PWD.UPD","DATA");
					srv.setParameter('usr', usr);
					srv.setParameter('pwd', newpass);
					srv.run();
					result.setvalue('status','INTEGER',0);			
				}
			}
		}
	</CODE>
	<ACCESSRULES><ACCESSRULE ID="admin"/></ACCESSRULES>
</SCRIPT>
