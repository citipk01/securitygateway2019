using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
//using com.citibank.latam.sg.library.db;
//using com.citibank.latam.sg.library.exception;

namespace SGDemoNET {
    /// <summary>
    /// Summary description for nonGUILogin.
    /// </summary>
    public class nonGUILogin : System.Windows.Forms.Form {
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelLogin;
        public System.Windows.Forms.TextBox pasword;
        private System.Windows.Forms.TextBox loginUSer;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

		private string configFile;
        private string systemId;
        public  string response    = "";
        public  int    returnValue = -1;

        public nonGUILogin( string par_ConfigFile, string par_SystemId) {

            configFile = par_ConfigFile; 
            systemId   = par_SystemId;

            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing ) {
            if( disposing ) {
                if(components != null) {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelLogin = new System.Windows.Forms.Label();
            this.pasword = new System.Windows.Forms.TextBox();
            this.loginUSer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(64, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(344, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Note: The Last Twelve Password Are Not Allowed";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(56, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Citi - Form for test of NonGUI Login";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(224, 200);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(96, 24);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.Black;
            this.btnLogin.Location = new System.Drawing.Point(120, 200);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(88, 24);
            this.btnLogin.TabIndex = 12;
            this.btnLogin.Text = "Login";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // labelPassword
            // 
            this.labelPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.ForeColor = System.Drawing.Color.Black;
            this.labelPassword.Location = new System.Drawing.Point(88, 152);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(64, 23);
            this.labelPassword.TabIndex = 6;
            this.labelPassword.Text = "Password";
            // 
            // labelLogin
            // 
            this.labelLogin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogin.ForeColor = System.Drawing.Color.Black;
            this.labelLogin.Location = new System.Drawing.Point(88, 104);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(56, 23);
            this.labelLogin.TabIndex = 7;
            this.labelLogin.Text = "Login Id";
            // 
            // pasword
            // 
            this.pasword.Location = new System.Drawing.Point(152, 152);
            this.pasword.Name = "pasword";
            this.pasword.PasswordChar = '*';
            this.pasword.Size = new System.Drawing.Size(192, 20);
            this.pasword.TabIndex = 11;
            // 
            // loginUSer
            // 
            this.loginUSer.Location = new System.Drawing.Point(152, 104);
            this.loginUSer.Name = "loginUSer";
            this.loginUSer.Size = new System.Drawing.Size(192, 20);
            this.loginUSer.TabIndex = 8;
            // 
            // nonGUILogin
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(448, 248);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.labelLogin);
            this.Controls.Add(this.pasword);
            this.Controls.Add(this.loginUSer);
            this.Name = "nonGUILogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "nonGUILogin";
            this.Load += new System.EventHandler(this.nonGUILogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private void btnLogin_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();
			
            // Data from editors
            string ssoLogin     = loginUSer.Text; 
            string ssoPassword  = pasword.Text;

            returnValue = sgInterface.noGuiLogin(systemId, "SGDemoNET", configFile, ssoLogin, ssoPassword, out response);
			
            this.Dispose();

        }

        private void btnCancel_Click(object sender, System.EventArgs e) {
                        this.Dispose();
        }

        private void nonGUILogin_Load(object sender, EventArgs e)
        {

        }

    }
}
