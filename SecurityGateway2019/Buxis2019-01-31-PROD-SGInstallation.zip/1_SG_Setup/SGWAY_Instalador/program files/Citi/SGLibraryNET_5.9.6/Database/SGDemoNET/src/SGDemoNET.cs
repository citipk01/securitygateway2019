using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using com.citibank.latam.sg.library.agent;
using com.citibank.latam.sg.library.parser;
using SO = System.Environment;


// using log4net;
// using log4net.Config;

// [assembly: log4net.Config.XmlConfigurator(ConfigFileExtension="log4net", Watch=true)]

namespace SGDemoNET {

	/// <summary>
	/// Summary description for SGDemoNET.
	/// </summary>
	
	public class frmSGDemoNET : System.Windows.Forms.Form {
        public System.Windows.Forms.TextBox vOutData;
        public System.Windows.Forms.Label lblOutData;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblModuleId;
        private System.Windows.Forms.TextBox edAuditData;
        private System.Windows.Forms.TextBox edAuditText;
        private System.Windows.Forms.TextBox edFunctionId;
        private System.Windows.Forms.TextBox edModuleId;
        private System.Windows.Forms.Label lblAuditData;
        private System.Windows.Forms.Label lblAuditText;
        private System.Windows.Forms.Label lblFunctionId;
        private System.Windows.Forms.Button btnAuditLog;
        private System.Windows.Forms.Button btnGetModFuncIds;
        private System.Windows.Forms.Button btnGetHierarchyModFuncIds;
        private System.Windows.Forms.Button btnGetFunctionNames;
        private System.Windows.Forms.Button btnGetExternalCredentials;
        private System.Windows.Forms.GroupBox grpAuthenticationTest;
        private System.Windows.Forms.TextBox edSystemId;
        private System.Windows.Forms.Button btnChangePass;
        private System.Windows.Forms.Label lblSystemId;
        private System.Windows.Forms.Button btnRsmsLogin;
        private System.Windows.Forms.Label lblConfigFile;
        private System.Windows.Forms.TextBox edConfigFile;
        public System.Windows.Forms.Label lblAuthStatus;

        private string configFile; 
        private string systemId;
        private string applicationName = "[SG Client Demo 5.0]";
        private System.Windows.Forms.GroupBox grpAuthenticatedTest;
        private System.Windows.Forms.CheckBox cbxTestNonGUI;
        private System.Windows.Forms.Button btnLogout;

        public  string response    = "";
        public  int    returnValue = -1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSGDemoNET() {
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

            // // Set up a simple configuration that logs on the console.
            // BasicConfigurator.Configure();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
		
			if( disposing )	{
			
				if (components != null) {
					components.Dispose();
				}
			
			}
			base.Dispose( disposing );
		
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.vOutData = new System.Windows.Forms.TextBox();
            this.lblOutData = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAuditLog = new System.Windows.Forms.Button();
            this.lblAuditData = new System.Windows.Forms.Label();
            this.lblAuditText = new System.Windows.Forms.Label();
            this.lblFunctionId = new System.Windows.Forms.Label();
            this.edAuditData = new System.Windows.Forms.TextBox();
            this.edAuditText = new System.Windows.Forms.TextBox();
            this.edFunctionId = new System.Windows.Forms.TextBox();
            this.edModuleId = new System.Windows.Forms.TextBox();
            this.lblModuleId = new System.Windows.Forms.Label();
            this.grpAuthenticatedTest = new System.Windows.Forms.GroupBox();
            this.btnGetModFuncIds = new System.Windows.Forms.Button();
            this.btnGetHierarchyModFuncIds = new System.Windows.Forms.Button();
            this.btnGetFunctionNames = new System.Windows.Forms.Button();
            this.btnGetExternalCredentials = new System.Windows.Forms.Button();
            this.grpAuthenticationTest = new System.Windows.Forms.GroupBox();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblAuthStatus = new System.Windows.Forms.Label();
            this.edSystemId = new System.Windows.Forms.TextBox();
            this.btnChangePass = new System.Windows.Forms.Button();
            this.lblSystemId = new System.Windows.Forms.Label();
            this.btnRsmsLogin = new System.Windows.Forms.Button();
            this.lblConfigFile = new System.Windows.Forms.Label();
            this.edConfigFile = new System.Windows.Forms.TextBox();
            this.cbxTestNonGUI = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.grpAuthenticatedTest.SuspendLayout();
            this.grpAuthenticationTest.SuspendLayout();
            this.SuspendLayout();
            // 
            // vOutData
            // 
            this.vOutData.AllowDrop = true;
            this.vOutData.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.vOutData.Location = new System.Drawing.Point(0, 346);
            this.vOutData.Multiline = true;
            this.vOutData.Name = "vOutData";
            this.vOutData.ReadOnly = true;
            this.vOutData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.vOutData.Size = new System.Drawing.Size(520, 139);
            this.vOutData.TabIndex = 13;
            // 
            // lblOutData
            // 
            this.lblOutData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutData.Location = new System.Drawing.Point(10, 397);
            this.lblOutData.Name = "lblOutData";
            this.lblOutData.Size = new System.Drawing.Size(595, 26);
            this.lblOutData.TabIndex = 14;
            this.lblOutData.Text = "Out Data:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAuditLog);
            this.groupBox1.Controls.Add(this.lblAuditData);
            this.groupBox1.Controls.Add(this.lblAuditText);
            this.groupBox1.Controls.Add(this.lblFunctionId);
            this.groupBox1.Controls.Add(this.edAuditData);
            this.groupBox1.Controls.Add(this.edAuditText);
            this.groupBox1.Controls.Add(this.edFunctionId);
            this.groupBox1.Controls.Add(this.edModuleId);
            this.groupBox1.Controls.Add(this.lblModuleId);
            this.groupBox1.Location = new System.Drawing.Point(10, 258);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(604, 130);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "3) Audit Data";
            // 
            // btnAuditLog
            // 
            this.btnAuditLog.Location = new System.Drawing.Point(499, 18);
            this.btnAuditLog.Name = "btnAuditLog";
            this.btnAuditLog.Size = new System.Drawing.Size(90, 27);
            this.btnAuditLog.TabIndex = 18;
            this.btnAuditLog.Text = "&Audit Log";
            this.btnAuditLog.Click += new System.EventHandler(this.btnAuditLog_Click);
            // 
            // lblAuditData
            // 
            this.lblAuditData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuditData.Location = new System.Drawing.Point(259, 28);
            this.lblAuditData.Name = "lblAuditData";
            this.lblAuditData.Size = new System.Drawing.Size(87, 18);
            this.lblAuditData.TabIndex = 17;
            this.lblAuditData.Text = "Audit Data:";
            // 
            // lblAuditText
            // 
            this.lblAuditText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuditText.Location = new System.Drawing.Point(10, 102);
            this.lblAuditText.Name = "lblAuditText";
            this.lblAuditText.Size = new System.Drawing.Size(120, 18);
            this.lblAuditText.TabIndex = 16;
            this.lblAuditText.Text = "Audit Text:";
            // 
            // lblFunctionId
            // 
            this.lblFunctionId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunctionId.Location = new System.Drawing.Point(10, 65);
            this.lblFunctionId.Name = "lblFunctionId";
            this.lblFunctionId.Size = new System.Drawing.Size(120, 26);
            this.lblFunctionId.TabIndex = 15;
            this.lblFunctionId.Text = "Function Id:";
            // 
            // edAuditData
            // 
            this.edAuditData.Location = new System.Drawing.Point(259, 55);
            this.edAuditData.Multiline = true;
            this.edAuditData.Name = "edAuditData";
            this.edAuditData.Size = new System.Drawing.Size(240, 65);
            this.edAuditData.TabIndex = 14;
            // 
            // edAuditText
            // 
            this.edAuditText.Location = new System.Drawing.Point(134, 97);
            this.edAuditText.Name = "edAuditText";
            this.edAuditText.Size = new System.Drawing.Size(120, 22);
            this.edAuditText.TabIndex = 13;
            // 
            // edFunctionId
            // 
            this.edFunctionId.Location = new System.Drawing.Point(134, 65);
            this.edFunctionId.Name = "edFunctionId";
            this.edFunctionId.Size = new System.Drawing.Size(120, 22);
            this.edFunctionId.TabIndex = 12;
            // 
            // edModuleId
            // 
            this.edModuleId.Location = new System.Drawing.Point(134, 28);
            this.edModuleId.Name = "edModuleId";
            this.edModuleId.Size = new System.Drawing.Size(120, 22);
            this.edModuleId.TabIndex = 11;
            // 
            // lblModuleId
            // 
            this.lblModuleId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModuleId.Location = new System.Drawing.Point(10, 37);
            this.lblModuleId.Name = "lblModuleId";
            this.lblModuleId.Size = new System.Drawing.Size(120, 26);
            this.lblModuleId.TabIndex = 7;
            this.lblModuleId.Text = "Module Id:";
            // 
            // grpAuthenticatedTest
            // 
            this.grpAuthenticatedTest.Controls.Add(this.btnGetModFuncIds);
            this.grpAuthenticatedTest.Controls.Add(this.btnGetHierarchyModFuncIds);
            this.grpAuthenticatedTest.Controls.Add(this.btnGetFunctionNames);
            this.grpAuthenticatedTest.Controls.Add(this.btnGetExternalCredentials);
            this.grpAuthenticatedTest.Location = new System.Drawing.Point(10, 157);
            this.grpAuthenticatedTest.Name = "grpAuthenticatedTest";
            this.grpAuthenticatedTest.Size = new System.Drawing.Size(604, 92);
            this.grpAuthenticatedTest.TabIndex = 24;
            this.grpAuthenticatedTest.TabStop = false;
            this.grpAuthenticatedTest.Text = "2) Authenticated Tests:";
            // 
            // btnGetModFuncIds
            // 
            this.btnGetModFuncIds.Location = new System.Drawing.Point(29, 18);
            this.btnGetModFuncIds.Name = "btnGetModFuncIds";
            this.btnGetModFuncIds.Size = new System.Drawing.Size(201, 27);
            this.btnGetModFuncIds.TabIndex = 27;
            this.btnGetModFuncIds.Text = "Get Module Functions Ids";
            this.btnGetModFuncIds.Click += new System.EventHandler(this.btnGetModFuncIds_Click);
            // 
            // btnGetHierarchyModFuncIds
            // 
            this.btnGetHierarchyModFuncIds.Location = new System.Drawing.Point(240, 18);
            this.btnGetHierarchyModFuncIds.Name = "btnGetHierarchyModFuncIds";
            this.btnGetHierarchyModFuncIds.Size = new System.Drawing.Size(230, 27);
            this.btnGetHierarchyModFuncIds.TabIndex = 26;
            this.btnGetHierarchyModFuncIds.Text = "Get Hierarchy Module Functions Ids";
            this.btnGetHierarchyModFuncIds.Click += new System.EventHandler(this.btnGetHierarchyModFuncIds_Click);
            // 
            // btnGetFunctionNames
            // 
            this.btnGetFunctionNames.Location = new System.Drawing.Point(29, 55);
            this.btnGetFunctionNames.Name = "btnGetFunctionNames";
            this.btnGetFunctionNames.Size = new System.Drawing.Size(201, 27);
            this.btnGetFunctionNames.TabIndex = 25;
            this.btnGetFunctionNames.Text = "Get &Function Names";
            this.btnGetFunctionNames.Click += new System.EventHandler(this.btnGetFunctionNames_Click);
            // 
            // btnGetExternalCredentials
            // 
            this.btnGetExternalCredentials.Location = new System.Drawing.Point(240, 55);
            this.btnGetExternalCredentials.Name = "btnGetExternalCredentials";
            this.btnGetExternalCredentials.Size = new System.Drawing.Size(230, 27);
            this.btnGetExternalCredentials.TabIndex = 22;
            this.btnGetExternalCredentials.Text = "Get E&xternal Credentials";
            this.btnGetExternalCredentials.Click += new System.EventHandler(this.btnGetExternalCredentials_Click);
            // 
            // grpAuthenticationTest
            // 
            this.grpAuthenticationTest.Controls.Add(this.btnLogout);
            this.grpAuthenticationTest.Controls.Add(this.lblAuthStatus);
            this.grpAuthenticationTest.Controls.Add(this.edSystemId);
            this.grpAuthenticationTest.Controls.Add(this.btnChangePass);
            this.grpAuthenticationTest.Controls.Add(this.lblSystemId);
            this.grpAuthenticationTest.Controls.Add(this.btnRsmsLogin);
            this.grpAuthenticationTest.Location = new System.Drawing.Point(10, 55);
            this.grpAuthenticationTest.Name = "grpAuthenticationTest";
            this.grpAuthenticationTest.Size = new System.Drawing.Size(604, 93);
            this.grpAuthenticationTest.TabIndex = 25;
            this.grpAuthenticationTest.TabStop = false;
            this.grpAuthenticationTest.Text = "1) Authentication Tests: ";
            // 
            // btnLogout
            // 
            this.btnLogout.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnLogout.Location = new System.Drawing.Point(240, 55);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(77, 28);
            this.btnLogout.TabIndex = 31;
            this.btnLogout.Text = "Logout";
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblAuthStatus
            // 
            this.lblAuthStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthStatus.Location = new System.Drawing.Point(336, 18);
            this.lblAuthStatus.Name = "lblAuthStatus";
            this.lblAuthStatus.Size = new System.Drawing.Size(250, 65);
            this.lblAuthStatus.TabIndex = 28;
            this.lblAuthStatus.Text = "You are not authenticated !";
            this.lblAuthStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // edSystemId
            // 
            this.edSystemId.Location = new System.Drawing.Point(144, 18);
            this.edSystemId.Name = "edSystemId";
            this.edSystemId.Size = new System.Drawing.Size(86, 22);
            this.edSystemId.TabIndex = 24;
            // 
            // btnChangePass
            // 
            this.btnChangePass.Location = new System.Drawing.Point(96, 55);
            this.btnChangePass.Name = "btnChangePass";
            this.btnChangePass.Size = new System.Drawing.Size(134, 27);
            this.btnChangePass.TabIndex = 27;
            this.btnChangePass.Text = "Change Password";
            this.btnChangePass.Click += new System.EventHandler(this.btnChangePass_Click);
            // 
            // lblSystemId
            // 
            this.lblSystemId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystemId.Location = new System.Drawing.Point(58, 18);
            this.lblSystemId.Name = "lblSystemId";
            this.lblSystemId.Size = new System.Drawing.Size(76, 19);
            this.lblSystemId.TabIndex = 25;
            this.lblSystemId.Text = "System Id:";
            // 
            // btnRsmsLogin
            // 
            this.btnRsmsLogin.Location = new System.Drawing.Point(10, 55);
            this.btnRsmsLogin.Name = "btnRsmsLogin";
            this.btnRsmsLogin.Size = new System.Drawing.Size(76, 27);
            this.btnRsmsLogin.TabIndex = 26;
            this.btnRsmsLogin.Text = "Login";
            this.btnRsmsLogin.Click += new System.EventHandler(this.btnRsmsLogin_Click);
            // 
            // lblConfigFile
            // 
            this.lblConfigFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfigFile.Location = new System.Drawing.Point(19, 18);
            this.lblConfigFile.Name = "lblConfigFile";
            this.lblConfigFile.Size = new System.Drawing.Size(77, 27);
            this.lblConfigFile.TabIndex = 31;
            this.lblConfigFile.Text = "Config File:";
            // 
            // edConfigFile
            // 
            this.edConfigFile.Location = new System.Drawing.Point(106, 18);
            this.edConfigFile.Name = "edConfigFile";
            this.edConfigFile.Size = new System.Drawing.Size(316, 22);
            this.edConfigFile.TabIndex = 30;
            this.edConfigFile.TextChanged += new System.EventHandler(this.edConfigFile_TextChanged);
            // 
            // cbxTestNonGUI
            // 
            this.cbxTestNonGUI.Location = new System.Drawing.Point(432, 18);
            this.cbxTestNonGUI.Name = "cbxTestNonGUI";
            this.cbxTestNonGUI.Size = new System.Drawing.Size(173, 28);
            this.cbxTestNonGUI.TabIndex = 32;
            this.cbxTestNonGUI.Text = "Test Non GUI Methods";
            // 
            // frmSGDemoNET
            // 
            this.AcceptButton = this.btnRsmsLogin;
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.ClientSize = new System.Drawing.Size(520, 485);
            this.Controls.Add(this.cbxTestNonGUI);
            this.Controls.Add(this.lblConfigFile);
            this.Controls.Add(this.edConfigFile);
            this.Controls.Add(this.vOutData);
            this.Controls.Add(this.grpAuthenticationTest);
            this.Controls.Add(this.grpAuthenticatedTest);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblOutData);
            this.Name = "frmSGDemoNET";
            this.Load += new System.EventHandler(this.frmSGDemoNET_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpAuthenticatedTest.ResumeLayout(false);
            this.grpAuthenticationTest.ResumeLayout(false);
            this.grpAuthenticationTest.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(){
			Application.Run(new frmSGDemoNET());
		}


        private void btnRsmsLogin_Click(object sender, System.EventArgs e) {

            // Data from editors
            configFile = edConfigFile.Text; 
            systemId   = edSystemId.Text;

            if(configFile.Trim()=="") {
                MessageBox.Show("Config File cannot be empty");
                return;
            }

            if(systemId.Trim()=="") {
                MessageBox.Show("System Id cannot be empty");
                return;
            }

            if (cbxTestNonGUI.Checked) {

                nonGUILogin login = new nonGUILogin(configFile, systemId);

                login.ShowDialog();

                response    = login.response;
                returnValue = login.returnValue;

            } else {

                // Instance the SGLibrary
                SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

                returnValue = sgInterface.RsmsLogin(systemId, applicationName, configFile, out response);
			
            }

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            if (returnValue == 1) {

                lblAuthStatus.Text = " You are authenticated as : " + obfuscatedResponse;

            } else {

                lblAuthStatus.Text = " You are not authenticated !";

            }

            lblOutData.Text = "Out data of last action [Login]: ";  
 			/**************************************************************************************************************************/
            string outData =    " returnValue = [" + returnValue + "] \n";

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private void btnChangePass_Click(object sender, System.EventArgs e) {
			
            // Data from editors
            configFile = edConfigFile.Text; 
            systemId   = edSystemId.Text;

            if(configFile.Trim()=="") {
                MessageBox.Show("Config File cannot be empty");
                return;
            }

            if(systemId.Trim()=="") {
                MessageBox.Show("System Id cannot be empty");
                return;
            }

            if (cbxTestNonGUI.Checked) {

                nonGUIChangePassword change = new nonGUIChangePassword(configFile, systemId);
                change.ShowDialog();

                response    = change.response;
                returnValue = change.returnValue;

                MessageBox.Show("response = [" + response + "]");
                MessageBox.Show("returnValue = [" + returnValue + "]");

            } else {

                // Instance the SGLibrary
                SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

                returnValue = sgInterface.ChangePass(systemId, applicationName, configFile, out response);
			
            }
			
            lblOutData.Text = "Out data of last action [Change Password]: ";  
 			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private void btnGetModFuncIds_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiAccModFuncIds(out response);

            } else {

                response = sgInterface.AccModFuncIds();

            }
			
            lblOutData.Text = "Out data of last action [Get Module Function Ids]: ";  
 			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private void btnGetHierarchyModFuncIds_Click(object sender, System.EventArgs e) {
                
            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiAccHieModFuncIds(out response);

            } else {

                response = sgInterface.AccHieModFuncIds();

            }
			
            lblOutData.Text = "Out data of last action [Get Hierarchy Module Functions Ids]: ";  
 			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private void btnGetFunctionNames_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiAccFunctions(out response);

            } else {

                response = sgInterface.AccFunctions();

            }
			
            lblOutData.Text = "Out data of last action [Get Function Names]: ";  
 			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;
        
        }

        private void btnGetExternalCredentials_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiAccExtUserCred(out response);

            } else {

                response = sgInterface.AccExtUserCred();

            }

            lblOutData.Text = "Out data of last action [Get External Credentials]: ";

            string outData = " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";

            vOutData.Text = outData;

        }

        private void btnAuditLog_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();
			
            // Data from editors
            short systemID   = (short)Int32.Parse(edSystemId.Text);
            short moduleID   = (short)Int32.Parse(edModuleId.Text);
            short functionID = (short)Int32.Parse(edFunctionId.Text);
            string auditText = edAuditText.Text;
            string dataText  = edAuditData.Text;

            if(systemID == 0) {
                MessageBox.Show("System Id cannot be empty or 0");
                return;
            }

            if(moduleID == 0) {
                MessageBox.Show("Module Id cannot be empty or 0");
                return;
            }

            if(functionID == 0) {
                MessageBox.Show("Fucntion Id cannot be empty or 0");
                return;
            }

            if(auditText.Trim()=="") {
                MessageBox.Show("Audit Text cannot be empty");
                return;
            }
  
            if(dataText.Trim()=="") {
                MessageBox.Show("Audit Data cannot be empty");
                return;
            }

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiAuditLog(systemID, moduleID, functionID, auditText, dataText, out response);

            } else {

                returnValue = sgInterface.AuditLog(systemID, moduleID, functionID, auditText, dataText);

            }
			
            lblOutData.Text = "Out data of last action [Audit Log]: "; 
 			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private void btnLogout_Click(object sender, System.EventArgs e) {

            // Instance the SGLibrary
            SGInterface sgInterface = FactorySGInstance.getInstanceInterface();

            if (cbxTestNonGUI.Checked) {

                returnValue = sgInterface.noGuiLogout(out response);

            } else {

                response = sgInterface.Logout();

            }

            lblAuthStatus.Text = " You are not authenticated !";

            lblOutData.Text = "Out data of last action [Logout]: ";  
			
            string outData =    " returnValue = [" + returnValue + "] \n";

            string obfuscatedResponse = Parser.obfuscateFields(response, "|", 1);

            outData = outData + " response    = [" + obfuscatedResponse + "] \n";
            
            vOutData.Text = outData;

        }

        private string getDefaultConfigFileName(){
            string retValue;
            string versionSO = SO.OSVersion.Version.Major.ToString() + "." + SO.OSVersion.Version.MajorRevision.ToString();
            switch (versionSO) {
                case "6.1"  : retValue = "C:\\Windows\\SysWOW64\\config.xml"; 
                              break;
                default     : retValue = "C:\\WINNT\\system32\\config.xml";  
                              break;
            }
            return retValue;
        }

        private void edConfigFile_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void frmSGDemoNET_Load(object sender, EventArgs e)
        {
            this.Text = "SGDemoNET Version 5.9.6 for " + SGAgent.AGENT_VERSION_VALUE + ".";

            this.edConfigFile.Text = getDefaultConfigFileName();
        }

	}
}
